from django.shortcuts import render
from django.http import JsonResponse
from textblob import TextBlob
from sklearn.linear_model import LinearRegression
import numpy as np

class ChatBot:
    def __init__(self):
        # Initialize a simple regression model (example)
        self.model = LinearRegression()

    def get_response(self, message):
        # Handle specific user prompts
        if "hi" in message.lower():
            return "Hello! How can I assist you today?"
        elif "course details" in message.lower():
            return "Please contact us at (number to be provided)."
        elif "location" in message.lower():
            return "You can find us here: (location link)"
        else:
            return self.analyze_sentiment(message)

    def analyze_sentiment(self, message):
        # Analyze the sentiment of the message
        analysis = TextBlob(message)
        sentiment = analysis.sentiment.polarity
        if sentiment > 0:
            return "You seem happy!"
        elif sentiment == 0:
            return "I'm here to assist!"
        else:
            return "You seem upset. Can I help with something?"

    def perform_regression(self, data):
        # Perform a simple regression (dummy example)
        x = np.array([[1], [2], [3], [4], [5]])
        y = np.array([1, 2, 3, 4, 5])
        self.model.fit(x, y)
        prediction = self.model.predict(np.array([[data]]))
        return f"Regression analysis result: {prediction[0]}"

# View for rendering the chat page
def chat_page(request):
    return render(request, 'chatbot/chat.html')

# API view to handle user messages
def chatbot_response(request):
    if request.method == 'POST':
        message = request.POST.get('message', '')
        bot = ChatBot()
        response = bot.get_response(message)
        return JsonResponse({'response': response})
