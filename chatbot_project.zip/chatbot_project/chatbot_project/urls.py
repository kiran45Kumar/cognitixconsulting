from django.contrib import admin
from django.urls import path
from chatbot import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('chat/', views.chat_page, name='chat_page'),
    path('api/chat/', views.chatbot_response, name='chatbot_response'),
]
